const form = document.getElementById('payment-form');
const notice = document.getElementById('notice');
document.getElementById('year').textContent = new Date().getFullYear();

form.addEventListener('submit', (event) => {
  event.preventDefault();
  const amount = Number(document.getElementById('amount').value);
  const rawPhone = document.getElementById('phone').value.trim();
  const phone = rawPhone.replace(/[\s()-]/g, '');

  if (!Number.isInteger(amount) || amount < 1 || amount > 250000) {
    notice.textContent = 'Please enter a whole-number amount between KSh 1 and KSh 250,000.';
    return;
  }
  if (!/^(?:\+?254|0)(?:7|1)\d{8}$/.test(phone)) {
    notice.textContent = 'Please enter a valid Kenyan mobile number, such as 0712345678 or 254712345678.';
    return;
  }

  notice.innerHTML = '<strong>Demo only:</strong> Your details look valid, but no STK Push has been sent. This website must be connected to a secure server and approved Safaricom Daraja credentials before it can request payment.';
});
